/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Buku;

/**
 *
 * @author ASUS
 */
public class Buku {
    private String judul;
    private String status = "tersedia";
    private String idPeminjam;
    
    public Buku(String judul) {
        this.judul = judul;
    }
    
    public String getJudul() {
        return this.judul;
    }
    
    public synchronized String getStatus() {
        return this.status;
    }
    
    public synchronized String getIdPeminjam() {
        return this.idPeminjam;
    }
    
    public synchronized void pinjamBuku(String judul, String idPeminjam) {
        if(status == "tersedia") {
            this.idPeminjam = idPeminjam;
            status = "dipinjam";
        } else {
            System.out.println("Maaf, buku sudah dipinjam");
        }
    }
    
    public synchronized void kembalikanBuku(String judul, String idPeminjam) {
        if(status == "dipinjam") {
            this.idPeminjam = null;
            status = "tersedia";
        }
    }
}
