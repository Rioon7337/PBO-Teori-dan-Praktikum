/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Buku;

/**
 *
 * @author ASUS
 */
public class Main {

    public static void main(String[] args) {
        Buku[] daftarBuku = {
            new Buku("Tutorial Pemrograman"),
            new Buku("Java Programing Languange"),
            new Buku("Cara Manajemen Waktu"),
            new Buku("Programming 101"),
            new Buku("Programming for Dummies")
        };
        
        String[] daftarPengunjung = {"001", "002", "003", "004", "005"};
    }
}
