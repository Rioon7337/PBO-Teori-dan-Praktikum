/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multiple_Inheritance;

/*
Nama  : Johannes Rein Gerardo Lumban Tobing
NIM   : 41425034
Prodi : D4 TRPL
*/

class AmphibiousVehicle implements LandVehicle, WaterVehicle{
    AmphibiousVehicle() {
        System.out.println("This is an AmphibiousVehicle");
    }
}
