/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pascal Felipe Sawaki
 */

/*
SOAL EKSPERIMEN 2: Buat class MotorKurir extends KendaraanEkspedisi,
TANPA method angkutBarang(). Arahkan kursor ke garis merah error.
Tuliskan dua opsi solusi dari IDE!

JAWAB:
  Error: "MotorKurir is not abstract and does not override
          abstract method angkutBarang(String) in KendaraanEkspedisi"
  Dua opsi solusi IDE:
    1) Implement all abstract methods
    2) Make MotorKurir abstract

CATATAN: File ini SENGAJA error untuk keperluan analisis.
 */

class MotorKurir extends KendaraanEkspedisi {
    public MotorKurir(String noPolisi, int kapasitasKg) {
        super(noPolisi, kapasitasKg);
    }

    // angkutBarang() sengaja belum ditulis → memicu error di atas
}