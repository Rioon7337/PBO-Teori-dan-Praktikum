/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pascal Felipe Sawaki
 */

/*
SOAL : Mengapa compiler bisa tentukan method mana yang jalan?
JAWAB: Compiler cek SIGNATURE (nama + tipe/jumlah/urutan parameter), dipilih saat COMPILE-TIME.
SOAL : Mengapa `int hitungOngkir(double)` ditolak?
JAWAB: Overloading tidak boleh beda return type saja. Signature-nya sama → "method hitungOngkir(double) is already defined".
 */

// Compile-Time Polymorphism:
class MesinTarif {
    private String kotaAsal;
    
    public MesinTarif(String kotaAsal) {
        this.kotaAsal = kotaAsal;
    }
    
    // Overload 1: berat
    public double hitungOngkir(double beratKg) {
        return beratKg * 10000;
    }
    
    // Overload 2: berat + asuransi
    public double hitungOngkir(double beratKg, double nilaiBarang) {
        double biayaAsuransi = nilaiBarang * 0.01;
        return (beratKg * 10000) + biayaAsuransi;
    }
    
    // Overload 3: berat + express
    public double hitungOngkir(double beratKg, boolean isExpress) {
        double total = beratKg + 10000;
        if (isExpress) total += 20000;
        return total;
    }
}

public class SimulasiOverloading {
    public static void main(String[] args) {
        System.out.println("=== INI METHOD OVERLOADING ===");
        MesinTarif tarif = new MesinTarif("Medan");
        
        // Compiler pilih method sesuai dengan parameter
        System.out.println("Ongkir Biasa(2.0Kg)            : Rp " + tarif.hitungOngkir(2.0));
        System.out.println("Ongkir + Asuransi (Barang 50Jt): Rp " + tarif.hitungOngkir(2.0, 50000000));
        System.out.println("Ongkir Express (2,0Kg)         : " + tarif.hitungOngkir(2.0, true));
    }
}
